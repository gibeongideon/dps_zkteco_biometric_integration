# -*- coding: utf-8 -*-
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2024 DOTSPRIME SYSTEM LLP
#    Email : sales@dotsprime.com / dotsprime@gmail.com
########################################################

from . import controllers
from . import models
from . import wizard
from . import zk

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: