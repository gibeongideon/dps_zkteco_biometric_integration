# -*- coding: utf-8 -*-
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2024 DOTSPRIME SYSTEM LLP
#    Email : sales@dotsprime.com / dotsprime@gmail.com
########################################################

from . import zkteco_device_settings
from . import zkteco_device_punching_logs
from . import hr_employee
from . import res_config_settings
from . import zkteco_device_event_logs
from . import device_stamp_logs
from . import hr_employee
from . import zkteco_device_states
from . import zkteco_user_fingerprints
from . import zkteco_cmds
from . import dashboard_dashboard