# -*- coding: utf-8 -*-
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2024 DOTSPRIME SYSTEM LLP
#    Email : sales@dotsprime.com / dotsprime@gmail.com
########################################################

from . import zkteco_device_attendance_create
from . import zkteco_attendance_device
from . import zkteco_device_attendance_report
from . import employee_leave_wizard
from . import attendance_reports

